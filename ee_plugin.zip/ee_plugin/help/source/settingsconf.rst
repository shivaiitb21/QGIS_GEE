.. _plugin_settings:

Plugin settings
===============

The plugin can be adjusted using the following settings, to be found in its settings dialog (|path_to_settings|).
